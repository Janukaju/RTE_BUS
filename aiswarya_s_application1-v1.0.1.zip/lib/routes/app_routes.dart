import 'package:flutter/material.dart';
import '../core/app_export.dart';
import '../presentation/app_navigation_screen/app_navigation_screen.dart';
import '../presentation/iphone_14_15_pro_max_eight_screen/iphone_14_15_pro_max_eight_screen.dart';
import '../presentation/iphone_14_15_pro_max_five_screen/iphone_14_15_pro_max_five_screen.dart';
import '../presentation/iphone_14_15_pro_max_seven_screen/iphone_14_15_pro_max_seven_screen.dart';
import '../presentation/iphone_14_15_pro_max_six_screen/iphone_14_15_pro_max_six_screen.dart'; // ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class AppRoutes {
  static const String iphone1415ProMaxSixScreen =
      '/iphone_14_15_pro_max_six_screen';

  static const String iphone1415ProMaxSevenScreen =
      '/iphone_14_15_pro_max_seven_screen';

  static const String iphone1415ProMaxEightScreen =
      '/iphone_14_15_pro_max_eight_screen';

  static const String iphone1415ProMaxFiveScreen =
      '/iphone_14_15_pro_max_five_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static const String initialRoute = '/initialRoute';

  static Map<String, WidgetBuilder> routes = {
    iphone1415ProMaxSixScreen: (context) => Iphone1415ProMaxSixScreen(),
    iphone1415ProMaxSevenScreen: (context) => Iphone1415ProMaxSevenScreen(),
    iphone1415ProMaxEightScreen: (context) => Iphone1415ProMaxEightScreen(),
    iphone1415ProMaxFiveScreen: (context) => Iphone1415ProMaxFiveScreen(),
    appNavigationScreen: (context) => AppNavigationScreen(),
    initialRoute: (context) => Iphone1415ProMaxSixScreen()
  };
}
