// ignore_for_file: must_be_immutable
class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

// iPhone 14 & 15 Pro Max - Six images
  static String imgVisaLogo1 = '$imagePath/img_visa_logo_1.png';

  static String img001 = '$imagePath/img_00_1.png';

// iPhone 14 & 15 Pro Max - Seven images
  static String imgD3dcf80967854 = '$imagePath/img_d3dcf809_6785_4.png';

// iPhone 14 & 15 Pro Max - Eight images
  static String imgTelevision = '$imagePath/img_television.svg';

  static String imgRectangle38 = '$imagePath/img_rectangle_38.png';

  static String imgCalendar1 = '$imagePath/img_calendar_1.png';

  static String imgRectangle37 = '$imagePath/img_rectangle_37.png';

  static String imgGroup22 = '$imagePath/img_group_22.png';

// iPhone 14 & 15 Pro Max - Five images
  static String imgCar1 = '$imagePath/img_car_1.png';

  static String imgSeat2 = '$imagePath/img_seat_2.png';

// Common images
  static String imgArrowright = '$imagePath/img_arrowright.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
