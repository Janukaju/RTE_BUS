import 'package:flutter/material.dart';
import '../../core/app_export.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/custom_elevated_button.dart';
import '../../widgets/custom_icon_button.dart';
import '../../widgets/custom_text_form_field.dart'; // ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class Iphone1415ProMaxSevenScreen extends StatelessWidget {
  Iphone1415ProMaxSevenScreen({Key? key})
      : super(
          key: key,
        );

  TextEditingController userNameController = TextEditingController();

  TextEditingController passwordController = TextEditingController();

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: Form(
          key: _formKey,
          child: SizedBox(
            width: double.maxFinite,
            child: Column(
              children: [
                SizedBox(height: 42.v),
                Expanded(
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        SizedBox(
                          height: 202.v,
                          width: 235.h,
                          child: Stack(
                            alignment: Alignment.bottomCenter,
                            children: [
                              CustomImageView(
                                imagePath: ImageConstant.imgD3dcf80967854,
                                height: 177.v,
                                width: 229.h,
                                radius: BorderRadius.circular(
                                  88.h,
                                ),
                                alignment: Alignment.topCenter,
                              ),
                              Align(
                                alignment: Alignment.bottomCenter,
                                child: Container(
                                  padding: EdgeInsets.all(12.h),
                                  decoration: AppDecoration
                                      .outlineSecondaryContainer
                                      .copyWith(
                                    borderRadius:
                                        BorderRadiusStyle.roundedBorder15,
                                  ),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      SizedBox(height: 5.v),
                                      RichText(
                                        text: TextSpan(
                                          children: [
                                            TextSpan(
                                              text: "Booking",
                                              style: CustomTextStyles
                                                  .headlineLargeOnPrimary,
                                            ),
                                            TextSpan(
                                              text: " Now",
                                              style: CustomTextStyles
                                                  .headlineLargeOrangeA400,
                                            )
                                          ],
                                        ),
                                        textAlign: TextAlign.left,
                                      )
                                    ],
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                        SizedBox(height: 61.v),
                        Text(
                          "Login to continue your booking",
                          style: CustomTextStyles.titleMediumPrimaryContainer,
                        ),
                        SizedBox(height: 23.v),
                        _buildUserName(context),
                        SizedBox(height: 26.v),
                        _buildPassword(context),
                        SizedBox(height: 40.v),
                        _buildLogin(context),
                        SizedBox(height: 3.v),
                        Text(
                          "forgot password?",
                          style: CustomTextStyles.titleSmallBlack900,
                        ),
                        SizedBox(height: 3.v),
                        _buildColumnquickeasy(context),
                        SizedBox(height: 29.v),
                        Text(
                          "Quick & Easy to travel anywhere anytime",
                          style: theme.textTheme.titleMedium,
                        ),
                        SizedBox(height: 25.v),
                        _buildStackSwipetosta(context)
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildUserName(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 28.h,
        right: 30.h,
      ),
      child: CustomTextFormField(
        controller: userNameController,
        hintText: "Username",
      ),
    );
  }

  /// Section Widget
  Widget _buildPassword(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 28.h,
        right: 30.h,
      ),
      child: CustomTextFormField(
        controller: passwordController,
        hintText: "Password",
        textInputAction: TextInputAction.done,
        textInputType: TextInputType.visiblePassword,
        obscureText: true,
      ),
    );
  }

  /// Section Widget
  Widget _buildLogin(BuildContext context) {
    return CustomElevatedButton(
      width: 129.h,
      text: "Login",
    );
  }

  /// Section Widget
  Widget _buildSwipeToStart(BuildContext context) {
    return Expanded(
      child: CustomElevatedButton(
        height: 45.v,
        text: "Swipe to Start",
        leftIcon: Container(
          padding: EdgeInsets.all(8.h),
          margin: EdgeInsets.only(right: 8.h),
          decoration: BoxDecoration(
            color: theme.colorScheme.primary,
            borderRadius: BorderRadius.circular(
              22.h,
            ),
          ),
          child: CustomImageView(
            imagePath: ImageConstant.imgArrowright,
            height: 29.adaptSize,
            width: 29.adaptSize,
          ),
        ),
        buttonStyle: CustomButtonStyles.fillOnPrimaryContainer,
        buttonTextStyle: CustomTextStyles.titleLargeInika,
      ),
    );
  }

  /// Section Widget
  Widget _buildColumnquickeasy(BuildContext context) {
    return Container(
      width: double.maxFinite,
      padding: EdgeInsets.symmetric(
        horizontal: 20.h,
        vertical: 11.v,
      ),
      decoration: AppDecoration.fillBlueGray.copyWith(
        borderRadius: BorderRadiusStyle.customBorderLR40,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          SizedBox(height: 112.v),
          Text(
            "Quick & Easy to travel anywhere anytime ......",
            style: theme.textTheme.titleSmall,
          ),
          SizedBox(height: 22.v),
          Align(
            alignment: Alignment.center,
            child: Padding(
              padding: EdgeInsets.only(
                left: 11.h,
                right: 5.h,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _buildSwipeToStart(context),
                  Container(
                    height: 30.adaptSize,
                    width: 30.adaptSize,
                    margin: EdgeInsets.only(
                      left: 28.h,
                      top: 8.v,
                      bottom: 7.v,
                    ),
                    decoration: BoxDecoration(
                      color: theme.colorScheme.onPrimaryContainer,
                      borderRadius: BorderRadius.circular(
                        11.h,
                      ),
                    ),
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildStackSwipetosta(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      elevation: 0,
      margin: EdgeInsets.all(0),
      color: theme.colorScheme.primaryContainer,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadiusStyle.customBorderLR30,
      ),
      child: Container(
        height: 60.v,
        width: double.maxFinite,
        padding: EdgeInsets.symmetric(
          horizontal: 31.h,
          vertical: 4.v,
        ),
        decoration: AppDecoration.fillPrimaryContainer.copyWith(
          borderRadius: BorderRadiusStyle.customBorderLR30,
        ),
        child: Stack(
          alignment: Alignment.topLeft,
          children: [
            Align(
              alignment: Alignment.centerLeft,
              child: Container(
                height: 45.v,
                width: 246.h,
                decoration: AppDecoration.fillOnPrimaryContainer.copyWith(
                  borderRadius: BorderRadiusStyle.roundedBorder22,
                ),
                child: CustomIconButton(
                  height: 45.adaptSize,
                  width: 45.adaptSize,
                  padding: EdgeInsets.all(8.h),
                  alignment: Alignment.centerLeft,
                  child: CustomImageView(
                    imagePath: ImageConstant.imgArrowright,
                  ),
                ),
              ),
            ),
            Align(
              alignment: Alignment.topLeft,
              child: Container(
                width: 143.h,
                margin: EdgeInsets.only(left: 53.h),
                child: Text(
                  "Swipe to Start",
                  maxLines: null,
                  overflow: TextOverflow.ellipsis,
                  style: CustomTextStyles.titleLargeInika,
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
