import 'package:flutter/material.dart';
import '../../core/app_export.dart';
import '../../widgets/custom_checkbox_button.dart';
import '../../widgets/custom_drop_down.dart';
import '../../widgets/custom_elevated_button.dart';
import '../../widgets/custom_icon_button.dart';
import '../../widgets/custom_text_form_field.dart'; // ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class Iphone1415ProMaxEightScreen extends StatelessWidget {
  Iphone1415ProMaxEightScreen({Key? key})
      : super(
          key: key,
        );

  List<String> dropdownItemList = ["Item One", "Item Two", "Item Three"];

  List<String> dropdownItemList1 = ["Item One", "Item Two", "Item Three"];

  TextEditingController calendaroneoneController = TextEditingController();

  TextEditingController valueoneController = TextEditingController();

  bool nonACCheckBox = false;

  bool acValueCheckBox = false;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: Column(
              children: [
                SizedBox(
                  height: 712.v,
                  width: double.maxFinite,
                  child: Stack(
                    alignment: Alignment.bottomCenter,
                    children: [
                      _buildTelevisionColumn(context),
                      Align(
                        alignment: Alignment.bottomCenter,
                        child: Container(
                          margin: EdgeInsets.symmetric(horizontal: 20.h),
                          padding: EdgeInsets.symmetric(vertical: 13.v),
                          decoration: AppDecoration.fillDeepPurple.copyWith(
                            borderRadius: BorderRadiusStyle.customBorderBL45,
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              SizedBox(height: 18.v),
                              _buildFromColumn(context),
                              SizedBox(height: 29.v),
                              _buildToColumn(context),
                              SizedBox(height: 19.v),
                              Divider(),
                              SizedBox(height: 8.v),
                              Padding(
                                padding: EdgeInsets.only(
                                  left: 18.h,
                                  right: 22.h,
                                ),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Padding(
                                      padding:
                                          EdgeInsets.symmetric(vertical: 7.v),
                                      child: Text(
                                        "Set the travel date ",
                                        style: theme.textTheme.titleLarge,
                                      ),
                                    ),
                                    CustomTextFormField(
                                      width: 40.adaptSize,
                                      controller: calendaroneoneController,
                                      borderDecoration:
                                          TextFormFieldStyleHelper.custom,
                                      filled: false,
                                    )
                                  ],
                                ),
                              ),
                              SizedBox(height: 10.v),
                              Divider(),
                              SizedBox(height: 10.v),
                              Padding(
                                padding: EdgeInsets.symmetric(horizontal: 18.h),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Padding(
                                      padding: EdgeInsets.only(
                                        top: 3.v,
                                        bottom: 6.v,
                                      ),
                                      child: Text(
                                        "Quantity",
                                        style: theme.textTheme.titleLarge,
                                      ),
                                    ),
                                    CustomTextFormField(
                                      width: 98.h,
                                      controller: valueoneController,
                                      hintText: "00",
                                      textInputAction: TextInputAction.done,
                                      contentPadding: EdgeInsets.symmetric(
                                        horizontal: 30.h,
                                        vertical: 5.v,
                                      ),
                                      borderDecoration: TextFormFieldStyleHelper
                                          .outlineBlackTL7,
                                      fillColor: appTheme.gray50,
                                    )
                                  ],
                                ),
                              ),
                              SizedBox(height: 16.v),
                              Divider(),
                              SizedBox(height: 10.v),
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Padding(
                                  padding: EdgeInsets.only(left: 18.h),
                                  child: Text(
                                    "Type of Transport",
                                    style: theme.textTheme.titleLarge,
                                  ),
                                ),
                              ),
                              SizedBox(height: 6.v),
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Padding(
                                  padding: EdgeInsets.only(
                                    left: 21.h,
                                    right: 58.h,
                                  ),
                                  child: Row(
                                    children: [
                                      _buildNonACCheckBox(context),
                                      _buildAcValueCheckBox(context)
                                    ],
                                  ),
                                ),
                              ),
                              SizedBox(height: 14.v),
                              Divider(),
                              SizedBox(height: 79.v),
                              CustomElevatedButton(
                                width: 200.h,
                                text: "Apply",
                              )
                            ],
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.topRight,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            CustomImageView(
                              imagePath: ImageConstant.imgRectangle37,
                              height: 74.v,
                              width: 57.h,
                            ),
                            Container(
                              margin: EdgeInsets.only(left: 87.h),
                              padding: EdgeInsets.symmetric(
                                horizontal: 32.h,
                                vertical: 19.v,
                              ),
                              decoration: BoxDecoration(
                                image: DecorationImage(
                                  image: AssetImage(
                                    ImageConstant.imgGroup22,
                                  ),
                                  fit: BoxFit.cover,
                                ),
                              ),
                              child: Column(
                                children: [
                                  SizedBox(height: 16.v),
                                  Text(
                                    "Reset",
                                    style:
                                        CustomTextStyles.titleSmallOrangeA400,
                                  )
                                ],
                              ),
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                ),
                SizedBox(height: 117.v),
                Text(
                  "Quick & Easy to travel anywhere anytime",
                  style: theme.textTheme.titleMedium,
                ),
                SizedBox(height: 25.v),
                _buildSwipeToStartStack(context)
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildTelevisionColumn(BuildContext context) {
    return Align(
      alignment: Alignment.topCenter,
      child: Container(
        padding: EdgeInsets.symmetric(
          horizontal: 30.h,
          vertical: 6.v,
        ),
        decoration: AppDecoration.fillBlueGray.copyWith(
          borderRadius: BorderRadiusStyle.customBorderBL45,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 24.v),
            CustomImageView(
              imagePath: ImageConstant.imgTelevision,
              height: 30.adaptSize,
              width: 30.adaptSize,
            ),
            SizedBox(height: 27.v),
            Align(
              alignment: Alignment.center,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 21.h),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      height: 91.v,
                      width: 57.h,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment(0.5, 0),
                          end: Alignment(0.5, 1),
                          colors: [
                            appTheme.deepPurple3007a,
                            appTheme.blueGray7007a
                          ],
                        ),
                      ),
                    ),
                    CustomImageView(
                      imagePath: ImageConstant.imgRectangle38,
                      height: 90.v,
                      width: 106.h,
                    )
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildFromColumn(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 18.h,
        right: 22.h,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "From",
            style: theme.textTheme.titleLarge,
          ),
          SizedBox(height: 4.v),
          CustomDropDown(
            items: dropdownItemList,
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildToColumn(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 18.h,
        right: 22.h,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "To",
            style: theme.textTheme.titleLarge,
          ),
          SizedBox(height: 4.v),
          CustomDropDown(
            items: dropdownItemList1,
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildNonACCheckBox(BuildContext context) {
    return CustomCheckboxButton(
      text: "Non A/C",
      value: nonACCheckBox,
      padding: EdgeInsets.symmetric(vertical: 3.v),
      onChange: (value) {
        nonACCheckBox = value;
      },
    );
  }

  /// Section Widget
  Widget _buildAcValueCheckBox(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 56.h),
      child: CustomCheckboxButton(
        text: "A/C",
        value: acValueCheckBox,
        padding: EdgeInsets.symmetric(vertical: 3.v),
        onChange: (value) {
          acValueCheckBox = value;
        },
      ),
    );
  }

  /// Section Widget
  Widget _buildSwipeToStartStack(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      elevation: 0,
      margin: EdgeInsets.all(0),
      color: theme.colorScheme.primaryContainer,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadiusStyle.customBorderLR30,
      ),
      child: Container(
        height: 60.v,
        width: double.maxFinite,
        padding: EdgeInsets.symmetric(
          horizontal: 31.h,
          vertical: 4.v,
        ),
        decoration: AppDecoration.fillPrimaryContainer.copyWith(
          borderRadius: BorderRadiusStyle.customBorderLR30,
        ),
        child: Stack(
          alignment: Alignment.topLeft,
          children: [
            Align(
              alignment: Alignment.centerLeft,
              child: Container(
                height: 45.v,
                width: 246.h,
                decoration: AppDecoration.fillOnPrimaryContainer.copyWith(
                  borderRadius: BorderRadiusStyle.roundedBorder22,
                ),
                child: CustomIconButton(
                  height: 45.adaptSize,
                  width: 45.adaptSize,
                  padding: EdgeInsets.all(8.h),
                  alignment: Alignment.centerLeft,
                  child: CustomImageView(
                    imagePath: ImageConstant.imgArrowright,
                  ),
                ),
              ),
            ),
            Align(
              alignment: Alignment.topLeft,
              child: Container(
                width: 143.h,
                margin: EdgeInsets.only(left: 53.h),
                child: Text(
                  "Swipe to Start",
                  maxLines: null,
                  overflow: TextOverflow.ellipsis,
                  style: CustomTextStyles.titleLargeInika,
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
