import 'package:flutter/material.dart';
import '../../core/app_export.dart';
import '../../widgets/custom_elevated_button.dart';
import 'widgets/grid_item_widget.dart';
import 'widgets/gridfive_item_widget.dart';

class Iphone1415ProMaxFiveScreen extends StatelessWidget {
  const Iphone1415ProMaxFiveScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: theme.colorScheme.onPrimaryContainer,
        body: SizedBox(
          width: double.maxFinite,
          child: Column(
            children: [
              SizedBox(height: 10.v),
              Expanded(
                child: SingleChildScrollView(
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 3.h),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        _buildClosingDateColumn(context),
                        SizedBox(height: 1.v),
                        _buildGridFive(context),
                        SizedBox(height: 1.v),
                        _buildRowSeatNineOne(context),
                        SizedBox(height: 1.v),
                        _buildGrid(context),
                        _buildRowSeatSeven(context),
                        SizedBox(height: 25.v),
                        _buildRowProceed(context),
                        SizedBox(height: 11.v),
                        _buildRowViewTwo(context),
                        SizedBox(height: 20.v),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Padding(
                            padding: EdgeInsets.only(left: 30.h),
                            child: Row(
                              children: [
                                Container(
                                  height: 27.adaptSize,
                                  width: 27.adaptSize,
                                  decoration: BoxDecoration(
                                    color: appTheme.orange800,
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsets.only(
                                    left: 11.h,
                                    top: 6.v,
                                  ),
                                  child: Text(
                                    "Reserved Seats",
                                    style: theme.textTheme.titleMedium,
                                  ),
                                )
                              ],
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildClosingDateColumn(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 30.h,
        right: 7.h,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.only(bottom: 20.v),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Closing Date",
                  style: CustomTextStyles.titleLargeRegular,
                ),
                SizedBox(height: 2.v),
                Padding(
                  padding: EdgeInsets.only(left: 6.h),
                  child: Text(
                    "2024-04-29",
                    style: theme.textTheme.titleMedium,
                  ),
                ),
                SizedBox(height: 8.v),
                Text(
                  "Closing Time",
                  style: CustomTextStyles.titleLargeRegular,
                ),
                SizedBox(height: 2.v),
                Text(
                  "17:30",
                  style: theme.textTheme.titleMedium,
                )
              ],
            ),
          ),
          Padding(
            padding: EdgeInsets.only(top: 16.v),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  "Rs.1,500.00",
                  style: theme.textTheme.headlineSmall,
                ),
                SizedBox(height: 27.v),
                CustomImageView(
                  imagePath: ImageConstant.imgCar1,
                  height: 50.v,
                  width: 61.h,
                  margin: EdgeInsets.only(right: 23.h),
                )
              ],
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildGridFive(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 30.h,
        right: 9.h,
      ),
      child: GridView.builder(
        shrinkWrap: true,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          mainAxisExtent: 51.v,
          crossAxisCount: 5,
          mainAxisSpacing: 0.h,
          crossAxisSpacing: 0.h,
        ),
        physics: NeverScrollableScrollPhysics(),
        itemCount: 60,
        itemBuilder: (context, index) {
          return GridfiveItemWidget();
        },
      ),
    );
  }

  /// Section Widget
  Widget _buildRowSeatNineOne(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 30.h,
        right: 9.h,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          SizedBox(
            height: 99.v,
            width: 145.h,
            child: Stack(
              alignment: Alignment.topLeft,
              children: [
                _buildStackSeatSix(
                  context,
                  seatNumber: "40",
                ),
                _buildStackSeatSix(
                  context,
                  seatNumber: "35",
                ),
                _buildStackSeatSix(
                  context,
                  seatNumber: "39",
                ),
                _buildStackSeatSix(
                  context,
                  seatNumber: "34",
                ),
                _buildStackSeatSix(
                  context,
                  seatNumber: "38",
                ),
                _buildStackSeatSix(
                  context,
                  seatNumber: "33",
                )
              ],
            ),
          ),
          Spacer(),
          Expanded(
            child: _buildColumnSeatEight(
              context,
              seatNumber1: "32",
              seatNumber2: "37",
            ),
          ),
          Expanded(
            child: Padding(
              padding: EdgeInsets.only(left: 6.h),
              child: _buildColumnSeatEight(
                context,
                seatNumber1: "31",
                seatNumber2: "36",
              ),
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildGrid(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 30.h,
        right: 9.h,
      ),
      child: GridView.builder(
        shrinkWrap: true,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          mainAxisExtent: 51.v,
          crossAxisCount: 5,
          mainAxisSpacing: 0.h,
          crossAxisSpacing: 0.h,
        ),
        physics: NeverScrollableScrollPhysics(),
        itemCount: 8,
        itemBuilder: (context, index) {
          return GridItemWidget();
        },
      ),
    );
  }

  /// Section Widget
  Widget _buildRowSeatSeven(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 30.h,
        right: 9.h,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          _buildStackSeatSix(
            context,
            seatNumber: "54",
          ),
          _buildStackSeatSix(
            context,
            seatNumber: "53",
          ),
          _buildStackSeatSix(
            context,
            seatNumber: "52",
          ),
          Padding(
            padding: EdgeInsets.only(left: 7.h),
            child: _buildStackSeatSix(
              context,
              seatNumber: "51",
            ),
          ),
          Padding(
            padding: EdgeInsets.only(left: 7.h),
            child: _buildStackSeatSix(
              context,
              seatNumber: "50",
            ),
          ),
          Padding(
            padding: EdgeInsets.only(left: 6.h),
            child: _buildStackSeatSix(
              context,
              seatNumber: "49",
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildRowProceed(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 30.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    height: 27.adaptSize,
                    width: 27.adaptSize,
                    decoration: BoxDecoration(
                      color: appTheme.deepPurpleA100,
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                      left: 9.h,
                      top: 4.v,
                      bottom: 2.v,
                    ),
                    child: Text(
                      "Counter seats",
                      style: theme.textTheme.titleMedium,
                    ),
                  )
                ],
              ),
              SizedBox(height: 18.v),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    height: 27.adaptSize,
                    width: 27.adaptSize,
                    decoration: BoxDecoration(
                      color: theme.colorScheme.primaryContainer,
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                      left: 9.h,
                      top: 2.v,
                      bottom: 4.v,
                    ),
                    child: Text(
                      "Available Seats",
                      style: theme.textTheme.titleMedium,
                    ),
                  )
                ],
              )
            ],
          ),
          CustomElevatedButton(
            width: 123.h,
            text: "Proceed",
            margin: EdgeInsets.only(
              top: 12.v,
              bottom: 20.v,
            ),
            buttonTextStyle: theme.textTheme.titleMedium!,
            onPressed: () {
              onTapProceed(context);
            },
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildRowViewTwo(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 30.h,
        right: 12.h,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Container(
            height: 27.adaptSize,
            width: 27.adaptSize,
            margin: EdgeInsets.only(top: 9.v),
            decoration: BoxDecoration(
              color: appTheme.yellow400,
            ),
          ),
          Padding(
            padding: EdgeInsets.only(
              left: 11.h,
              top: 13.v,
              bottom: 4.v,
            ),
            child: Text(
              "Processing Seats",
              style: theme.textTheme.titleMedium,
            ),
          ),
          Spacer(),
          Padding(
            padding: EdgeInsets.only(bottom: 7.v),
            child: Text(
              "Proceed",
              style: CustomTextStyles.headlineSmallOnPrimaryContainerExtraBold,
            ),
          )
        ],
      ),
    );
  }

  /// Common widget
  Widget _buildStackSeatSix(
    BuildContext context, {
    required String seatNumber,
  }) {
    return SizedBox(
      height: 50.adaptSize,
      width: 50.adaptSize,
      child: Stack(
        alignment: Alignment.topRight,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgSeat2,
            height: 50.adaptSize,
            width: 50.adaptSize,
            alignment: Alignment.center,
          ),
          Align(
            alignment: Alignment.topRight,
            child: Padding(
              padding: EdgeInsets.only(
                top: 11.v,
                right: 12.h,
              ),
              child: Text(
                seatNumber,
                style: theme.textTheme.titleMedium!.copyWith(
                  color: appTheme.black900,
                ),
              ),
            ),
          )
        ],
      ),
    );
  }

  /// Common widget
  Widget _buildColumnSeatEight(
    BuildContext context, {
    required String seatNumber1,
    required String seatNumber2,
  }) {
    return Column(
      children: [
        SizedBox(
          height: 50.adaptSize,
          width: 50.adaptSize,
          child: Stack(
            alignment: Alignment.topCenter,
            children: [
              CustomImageView(
                imagePath: ImageConstant.imgSeat2,
                height: 50.adaptSize,
                width: 50.adaptSize,
                alignment: Alignment.center,
              ),
              Align(
                alignment: Alignment.topCenter,
                child: Padding(
                  padding: EdgeInsets.only(top: 11.v),
                  child: Text(
                    seatNumber1,
                    style: theme.textTheme.titleMedium!.copyWith(
                      color: appTheme.black900,
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
        SizedBox(
          height: 50.adaptSize,
          width: 50.adaptSize,
          child: Stack(
            alignment: Alignment.topRight,
            children: [
              CustomImageView(
                imagePath: ImageConstant.imgSeat2,
                height: 50.adaptSize,
                width: 50.adaptSize,
                alignment: Alignment.center,
              ),
              Align(
                alignment: Alignment.topRight,
                child: Padding(
                  padding: EdgeInsets.only(
                    top: 10.v,
                    right: 12.h,
                  ),
                  child: Text(
                    seatNumber2,
                    style: theme.textTheme.titleMedium!.copyWith(
                      color: appTheme.black900,
                    ),
                  ),
                ),
              )
            ],
          ),
        )
      ],
    );
  }

  /// Navigates to the iphone1415ProMaxSixScreen when the action is triggered.
  onTapProceed(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.iphone1415ProMaxSixScreen);
  }
}
