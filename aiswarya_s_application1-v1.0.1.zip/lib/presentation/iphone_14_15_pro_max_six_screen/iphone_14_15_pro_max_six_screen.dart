import 'package:flutter/material.dart';
import '../../core/app_export.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/custom_elevated_button.dart';
import '../../widgets/custom_text_form_field.dart'; // ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class Iphone1415ProMaxSixScreen extends StatelessWidget {
  Iphone1415ProMaxSixScreen({Key? key})
      : super(
          key: key,
        );

  TextEditingController cardNumberController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: theme.colorScheme.primaryContainer,
        resizeToAvoidBottomInset: false,
        body: SizedBox(
          width: double.maxFinite,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              SizedBox(height: 19.v),
              Container(
                margin: EdgeInsets.only(left: 21.h),
                padding: EdgeInsets.symmetric(
                  horizontal: 4.h,
                  vertical: 23.v,
                ),
                decoration: AppDecoration.fillOnPrimaryContainer,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(left: 20.h),
                      child: Text(
                        "Payment Details",
                        style: CustomTextStyles.headlineLargeBold,
                      ),
                    ),
                    SizedBox(height: 24.v),
                    Padding(
                      padding: EdgeInsets.only(left: 20.h),
                      child: Text(
                        "Card Type",
                        style: CustomTextStyles.titleSmallBlack900Bold,
                      ),
                    ),
                    SizedBox(height: 10.v),
                    _buildRowViewOne(context),
                    SizedBox(height: 9.v),
                    _buildColumnCardNumber(context),
                    SizedBox(height: 19.v),
                    _buildRowExpiration(context),
                    SizedBox(height: 22.v),
                    Padding(
                      padding: EdgeInsets.only(left: 10.h),
                      child: Text(
                        "CVN",
                        style: theme.textTheme.titleMedium,
                      ),
                    ),
                    SizedBox(height: 2.v),
                    Container(
                      height: 40.v,
                      width: 80.h,
                      margin: EdgeInsets.only(left: 6.h),
                      decoration: BoxDecoration(
                        color: appTheme.blueGray100,
                        borderRadius: BorderRadius.circular(
                          5.h,
                        ),
                      ),
                    ),
                    SizedBox(height: 44.v),
                    _buildRowCancel(context),
                    SizedBox(height: 44.v)
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildRowViewOne(BuildContext context) {
    return Align(
      alignment: Alignment.centerRight,
      child: Padding(
        padding: EdgeInsets.only(left: 26.h),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Container(
                    height: 20.adaptSize,
                    width: 20.adaptSize,
                    margin: EdgeInsets.only(
                      top: 35.v,
                      bottom: 25.v,
                    ),
                    decoration: BoxDecoration(
                      color: appTheme.blueGray100,
                      borderRadius: BorderRadius.circular(
                        10.h,
                      ),
                    ),
                  ),
                  CustomImageView(
                    imagePath: ImageConstant.imgVisaLogo1,
                    height: 50.v,
                    width: 88.h,
                    margin: EdgeInsets.only(
                      left: 6.h,
                      top: 15.v,
                      bottom: 15.v,
                    ),
                  ),
                  Spacer(),
                  CustomImageView(
                    imagePath: ImageConstant.img001,
                    height: 80.v,
                    width: 125.h,
                    radius: BorderRadius.circular(
                      11.h,
                    ),
                  )
                ],
              ),
            ),
            Container(
              height: 20.adaptSize,
              width: 20.adaptSize,
              margin: EdgeInsets.only(
                top: 35.v,
                bottom: 25.v,
              ),
              decoration: BoxDecoration(
                color: appTheme.blueGray100,
                borderRadius: BorderRadius.circular(
                  10.h,
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildColumnCardNumber(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 5.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.only(left: 5.h),
            child: Text(
              "Card Number",
              style: theme.textTheme.titleMedium,
            ),
          ),
          SizedBox(height: 4.v),
          Padding(
            padding: EdgeInsets.only(right: 26.h),
            child: CustomTextFormField(
              controller: cardNumberController,
              textInputAction: TextInputAction.done,
              borderDecoration: TextFormFieldStyleHelper.fillBlueGray,
              fillColor: appTheme.blueGray100,
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildRowExpiration(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 6.h,
        right: 9.h,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: EdgeInsets.only(left: 1.h),
                child: Text(
                  "Expiration Month",
                  style: theme.textTheme.titleMedium,
                ),
              ),
              SizedBox(height: 5.v),
              Container(
                height: 40.v,
                width: 81.h,
                decoration: BoxDecoration(
                  color: appTheme.blueGray100,
                  borderRadius: BorderRadius.circular(
                    5.h,
                  ),
                ),
              )
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Expiration Year",
                style: theme.textTheme.titleMedium,
              ),
              SizedBox(height: 5.v),
              Container(
                height: 40.v,
                width: 81.h,
                margin: EdgeInsets.only(left: 16.h),
                decoration: BoxDecoration(
                  color: appTheme.blueGray100,
                  borderRadius: BorderRadius.circular(
                    5.h,
                  ),
                ),
              )
            ],
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildRowCancel(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 6.h,
        right: 9.h,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          CustomElevatedButton(
            height: 49.v,
            width: 112.h,
            text: "Cancel",
            buttonStyle: CustomButtonStyles.fillPrimaryContainer,
            buttonTextStyle: CustomTextStyles.headlineSmallOnPrimaryContainer_1,
          ),
          CustomElevatedButton(
            height: 49.v,
            width: 100.h,
            text: "Pay",
            buttonStyle: CustomButtonStyles.fillPrimaryContainer,
            buttonTextStyle: CustomTextStyles.headlineSmallOnPrimaryContainer,
          )
        ],
      ),
    );
  }
}
